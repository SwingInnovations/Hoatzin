window = {
	title = "Game",
	width = 640,
	height = 768
}
